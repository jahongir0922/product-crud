<script setup>
import { RouterView } from "vue-router";
</script>

<template>
  <div id="root">
    <RouterView />
  </div>
</template>

<style scoped lang="scss">
#root {
  // width: 100vw;
  // border: 1px solid red;
}

// @include media("<=tablet") {
// }
</style>
