import axios from "axios";
axios.defaults.baseURL = "http://94.158.54.194:9092/api/";
// axios.defaults.headers.common['Authorization'] = 'Bearer ' + localStorage.getItem('token')
